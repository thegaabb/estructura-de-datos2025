document.addEventListener('DOMContentLoaded', function() {
    const counterElement = document.getElementById('counter');
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    const resetBtn = document.getElementById('resetBtn');
    
    let counter = 0;
    let intervalId = null;
    let speed = 100; // velocidad inicial en ms
    
    // Función para actualizar el contador
    function updateCounter() {
        counterElement.textContent = counter.toLocaleString();
        counter++;
        
        // Aumentar velocidad progresivamente (sin condiciones que puedan detenerlo)
        if (counter % 1000 === 0 && speed > 1) {
            speed = Math.max(1, speed * 0.9); // Reducir velocidad un 10% cada 1000 incrementos
            clearInterval(intervalId);
            intervalId = setInterval(updateCounter, speed);
        }
    }
    
    // Iniciar el contador
    function startCounter() {
        if (!intervalId) {
            intervalId = setInterval(updateCounter, speed);
            startBtn.disabled = true;
            stopBtn.disabled = false;
        }
    }
    
    // Detener el contador
    function stopCounter() {
        clearInterval(intervalId);
        intervalId = null;
        startBtn.disabled = false;
        stopBtn.disabled = true;
    }
    
    // Reiniciar el contador
    function resetCounter() {
        stopCounter();
        counter = 0;
        speed = 100;
        counterElement.textContent = '0';
    }
    
    // Eventosssss
    startBtn.addEventListener('click', startCounter);
    stopBtn.addEventListener('click', stopCounter);
    resetBtn.addEventListener('click', resetCounter);
    
    // Efecto de animación para el número
    counterElement.addEventListener('mousemove', (e) => {
        const rect = counterElement.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const angleX = (y - centerY) / 10;
        const angleY = (centerX - x) / 10;
        
        counterElement.style.transform = `perspective(500px) rotateX(${angleX}deg) rotateY(${angleY}deg)`;
    });
    
    counterElement.addEventListener('mouseleave', () => {
        counterElement.style.transform = 'perspective(500px) rotateX(0) rotateY(0)';
    });
});